package com.example.kpl_project

class ValidationLibrary{

    fun validationBook(
        namaBuku: String,
        pengarang: String,
        penerbit : String,
        catatan: String,
        status: String):Boolean{

        if (namaBuku.isEmpty()){
            return false
        }
        if (pengarang.isEmpty()){
            return false
        }
        if (penerbit.isEmpty()){
            return false
        }
        if (catatan.count{it.isDigit()}<10){
            return false
        }
        if (namaBuku.isEmpty()){
            return false
        }

        return true
    }

}