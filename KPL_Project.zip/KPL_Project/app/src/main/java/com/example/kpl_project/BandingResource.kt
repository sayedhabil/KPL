package com.example.kpl_project

import android.content.Context

class BandingResources {
    fun isEqual (string: String, context: Context, resId: Int ): Boolean {
        return context.getString(resId) == string
    }
}
