package com.example.kpl_project

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class ValidationTest{
    /** TDD - Adapun penyataan yang tidak valid apabila...
     *        ... Salah satu dari kolom kosong/empty
     *        ... Catatan tidak lebih dari 10 digit
     */

    private val validation = ValidationLibrary()

    @Test
    fun `empty bookName return false`(){
        val result = validation.validationBook(
            "",
            "Sucipto",
            "Erlangga",
            "Buku Sekolah",
            "Rak 2B"

        )
        assertThat(result).isFalse()
    }
    @Test
    fun `empty pengarang return false`(){
        val result = validation.validationBook(
            "MATEMATIKA",
            "",
            "Erlangga",
            "Buku Sekolah",
            "Rak 2B"

        )
        assertThat(result).isFalse()
    }
    @Test
    fun `empty penerbit return false`(){
        val result = validation.validationBook(
            "MATEMATIKA",
            "Sucipto",
            "",
            "Buku Sekolah",
            "Rak 2B"

        )
        assertThat(result).isFalse()
    }
    @Test
    fun `empty catatan return false`(){
        val result = validation.validationBook(
            "MATEMATIKA",
            "Sucipto",
            "Erlangga",
            "",
            "Rak 2B"

        )
        assertThat(result).isFalse()
    }
    @Test
    fun `empty staus return false`(){
        val result = validation.validationBook(
            "MATEMATIKA",
            "Sucipto",
            "Erlangga",
            "Buku Sekolah",
            ""

        )
        assertThat(result).isFalse()
    }

}